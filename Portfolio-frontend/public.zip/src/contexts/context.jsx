//image-gen/client/src/contexts/context.jsx
import { createContext } from 'react';

export const userContext = createContext({});
