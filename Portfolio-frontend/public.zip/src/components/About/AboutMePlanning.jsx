// src/components/AboutMePlanning.jsx

import './AboutMePlanning.scss';

const AboutMePlanning = () => {
  return (
    <div className='aboutMePlanning'>
      <h2 className='it-not-stopped'>
        It hasn`t stopped yet.....it will never stop.
      </h2>
      <p className='learning-is-part'>
        Learning is part of my essence, as long as I continue learning, I will
        continue to grow, and as long as I continue to grow, I will certainly
        continue to achieve.
      </p>
    </div>
  );
};

export default AboutMePlanning;
