// PersonalWebSite\Portfolio-frontend\src\components\Blog\blogApp\BlogPublishForm.jsx

import { useContext } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import { IoMdClose } from 'react-icons/io';
import './BlogPublishForm.scss';
import { userContext } from '../../../contexts/context';

export const BlogPublishForm = () => {
  let {
    blog: [{ banner, title, tags, des }],
    setEditorState,
  } = useContext(userContext);

  // change the state of the handleCloseEvent
  const handleCloseEvent = () => {
    setEditorState('editor');
  };

  return (
    <>
      <section className='blogPublishForm'>
        <Toaster />

        <button className='blogPublishFormButton' onClick={handleCloseEvent}>
          <IoMdClose />
          <div>
            <p>preview</p>
            <div>
              <img src={banner} alt='' className='blogPublishFormBanner' />
            </div>
          </div>
        </button>
      </section>
    </>
  );
};
